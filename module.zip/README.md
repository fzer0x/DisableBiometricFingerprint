# Disable Fingerprint Magisk Module

This module is designed to fix a boot loop / high CPU usage issue caused by the `system_server` repeatedly trying to contact a non-functional Fingerprint HAL.

## What it does:
1. **Masks Permission XMLs**: Replaces `android.hardware.fingerprint.xml` and `android.hardware.biometrics.fingerprint.xml` with empty files in both `/system` and `/vendor`. This tells Android that the device does not have a fingerprint sensor.
2. **Sets System Properties**: Sets `config.disable_fingerprint=true` and `ro.fingerprint.disable=1` to further instruct the framework to ignore fingerprint hardware.
3. **Stops Services**: Attempts to stop common fingerprint HAL services (`android.hardware.biometrics.fingerprint@2.1-service`, `vendor.fps_hal`, etc.) during boot.

## Installation:
1. Zip the contents of this folder (not the folder itself).
2. Install via Magisk Manager.
3. Reboot.
